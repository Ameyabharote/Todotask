package com.practice.todolist.model;

public enum Status
{
    COMPLETED, NOT_COMPLETED
}
